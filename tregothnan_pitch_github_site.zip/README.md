# Tregothnan Tea Japan – Investor Pitch Site

## 📌 How to Deploy on GitHub Pages

1. Upload everything in this folder to a new **public GitHub repo**
2. Go to **Settings > Pages**
3. Under **Source**, choose `main` branch and `/root`
4. GitHub will give you a link like:
   https://yourusername.github.io/tregothnan-pitch/

To use a custom domain, add your domain in Settings > Pages and update your DNS with a CNAME record pointing to GitHub Pages.
